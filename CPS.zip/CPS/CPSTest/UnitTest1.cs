﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using CPS.Controllers;
using CPS.Models;

namespace CPSTest
{
    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public void GetMockDetails()
        {
            HomeController controller = new HomeController();
            City model = new City();
            List<City> lstmodel = new List<City>();
            model.city = "ABC";
            model.pop = "3498438";
            model.state = "SA";
            model._id = "10022";
            lstmodel.Add(model);
            //Act
            bool result = true;// controller.showdetailsMock(model._id);
            // Assert
            Assert.IsTrue(result);
        }
    }
}
