﻿using CPS.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace CPS.Controllers
{
    public class HomeController : Controller
    {

        /// <summary>
        /// Get Data from JSON file
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Index()
        {
            var webClient = new WebClient();
            var json = webClient.DownloadString(System.Web.HttpContext.Current.Server.MapPath(@"~/dummy.json"));
            var cities = JsonConvert.DeserializeObject<Cities>(json);
            return View(cities);
        }

        /// <summary>
        /// Show Details of City
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult showdetails(string id)
        {
            var webClient = new WebClient();
            City model = new Models.City();
            model._id = id;
            var json = webClient.DownloadString(System.Web.HttpContext.Current.Server.MapPath(@"~/dummy.json"));
            var cities = JsonConvert.DeserializeObject<Cities>(json);
            model = cities.cities.Where(a => a._id == id).Select(a => a).FirstOrDefault();
            return View(model);
        }

        /// <summary>
        /// Update JSON data 
        /// </summary>
        /// <param name="Model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult UpdateData(City Model)
        {
            try
            {
                var webClient = new WebClient();
                var json = webClient.DownloadString(System.Web.HttpContext.Current.Server.MapPath(@"~/dummy.json"));
                var cities = JsonConvert.DeserializeObject<Cities>(json);
                City IModel = cities.cities.Where(a => a._id == Model._id).FirstOrDefault();
                IModel.pop = Model.pop;
               // json = JsonConvert.SerializeObject(IModel);
                System.IO.File.WriteAllText(System.Web.HttpContext.Current.Server.MapPath(@"~/dummy.json"), json);
                return Json(new
                {
                    message = "success",
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    message = "Failure",
                }, JsonRequestBehavior.AllowGet);
            }
        }


        public bool showdetailsMock(string id)
        {

            return true;
        }


    }
}