﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CPS.Models
{
    public class City
    {
        public string city { get; set; }

        public string[] loc { get; set; }

        public string pop { get; set; }

        public string state { get; set; }
        public string _id { get; set; }

    }

    public class Cities
    {
        public IList<City> cities;
    }

   
}